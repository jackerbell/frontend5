import './App.css';
import { Component } from 'react';
import Counter from './Components/Counter';


class App extends Component {
  constructor(props){
    super(props)
    this.state={
      title:'My Counter'//하위 컴포넌트 요소에 넘길 값(이 코드에서는 Counter)
    }
  }

  render(){
    return(
      <div id='App'>
        <Counter title={this.state.title}></Counter>
      </div>
    )
  };

}

export default App;

