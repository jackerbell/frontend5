import './App.css';
import { Component } from 'react';
import InputComp from './Components/InputComp';
import Person from './Components/Person';


class App extends Component {
  constructor(props){
    super(props)
    this.state={
      personList:[
        {name:'이민호',age:20,height:176.6},
        {name:'정채연',age:21,height:162.4},
        {name:'송중기',age:22,height:177.8},
        {name:'김철수',age:23,height:176.2}
      ]
    }
  }

  addPersonInfo=(name,age,height)=>{
    alert('추가(App.js)')
    alert('추가할 이름:(App.js):'+name)
    alert('추가할 나이:(App.js):'+age)
    alert('추가할 키:(App.js):'+height)
    const personObj = {name:name,age:age,height:height}
    this.setState({
      personList:this.state.personList.concat(personObj)
    })
  }

  deletePerson=(name)=>{
    alert('삭제!(App.js)')
    alert('삭제할 이름(App.js):'+name)
  }

  render(){

    const result = this.state.personList.map(
      (data) =>(<Person name={data.name} age={data.age} height={data.height}></Person>)
      //위에서 데이터는 객체(JSON)를 가져오고 그안에 있는 배열요소를 모두 출력한다. 
    )
    
    return(
      <div id='App'>
        <InputComp addPersonInfo={this.addPersonInfo}/>
        {result}
      </div>
    )
  };

}

export default App;

