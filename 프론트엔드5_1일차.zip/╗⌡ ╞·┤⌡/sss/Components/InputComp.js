import { Component } from "react";
import '../CSS/InputComp.css'
class InputComp extends Component{
    constructor(props){
        super(props)
        this.state={
            name:'',
            age:0,
            height:0
        }
    }

    addPersonInfo=()=>{
        alert('작동(InputComp.js)')
        alert('추가할 이름(InputComp.js):'+this.state.name)
        alert('추가할 나이(InputComp.js):'+this.state.age)
        alert('추가할 키(InputComp.js):'+this.state.height)
        this.props.addPersonInfo(this.state.name,this.state.age,this.state.height)
    }

    nameChange=(e)=>{//매개변수에 이벤트 객체가 넘어오고
        console.log(e.target.value)//이벤트가 일어난 곳의 value 값을 넘겨줌
        this.setState({
            name:e.target.value
        })
    }

    ageChange=(e)=>{
        console.log(e.target.value)
        this.setState({
            age:e.target.value
        })
    }

    heightChange=(e)=>{
        console.log(e.target.value)
        this.setState({
            height:e.target.value
        })
    }

    render(){
        return(
            <div id="InputComp">
                <input type="text" placeholder="이름 입력" onChange={this.nameChange} />
                <input type="text" placeholder="나이 입력" onChange={this.ageChange} />
                <input type="text" placeholder="키 입력" onChange={this.heightChange}/>
                <button onClick={this.addPersonInfo}>추가</button>
            </div>
        )
    }
}

export default InputComp