import '../CSS/Person.css';
import { Component } from 'react';


class Person extends Component {
  constructor(props){
    super(props)
    this.state={

    }
  }

  deletePerson=()=>{
    alert('삭제!(Person.js)')
    this.props.deletePerson(this.props.name)
  }

  render(){
    return(
      <div id='Person'>
        <div>
            이름:{this.props.name}
        </div>
        <div>
            나이:{this.props.age}
        </div>
        <div>
            키:{this.props.height}
        </div>
        <button onClick={this.deletePerson}>삭제</button>
      </div>
    )
  };

}

export default Person;

