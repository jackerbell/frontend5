import '../CSS/Counter.css'
import { Component } from 'react';

class Counter extends Component {
  constructor(props){
    super(props)
    this.state={
        num:0
    }
  }


  increase=()=>{
    alert('증가!')
    this.setState({ 
      num:this.state.num+1 // num += 1 처럼 하려면 좌측처럼 작성해야함.
      /*
          this.state.num = this.state.num+1 을 하면 내부적으로는 수치가 바뀌나 
          화면에 렌더링이 안됨
          원인은 리액트의 라이프사이클과 연관이 있다.
          setState는 랜더링과 엮여있으므로 state만 바꿔도 랜더가 되지 않아 화면에 반영되지 않는다. 
      */
    })
  }

  decrease=()=>{
    alert('감소!')
    this.setState({
      num:this.state.num-1
    })

  }

  render(){
    return(
      <div id='Counter'>
        <h1>{this.props.title}</h1>
        <h2>num:{this.state.num}</h2>
        <button onClick={this.increase}>+</button>
        <button onClick={this.decrease}>-</button>
      </div>
    )
  };

}

export default Counter;
